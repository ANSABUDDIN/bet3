import React from 'react'
import Header from '../components/Elements/Header'
import Home from '../components/Home/Home'

const Layout = () => {
  return (
    <div>
      <Home />
    </div>
  )
}

export default Layout


